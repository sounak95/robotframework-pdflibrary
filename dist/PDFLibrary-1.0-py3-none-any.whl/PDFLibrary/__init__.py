# -*- coding: utf-8 -*-
from .PDFLibrary import PDFLibrary
from .version import VERSION
__version__ = VERSION